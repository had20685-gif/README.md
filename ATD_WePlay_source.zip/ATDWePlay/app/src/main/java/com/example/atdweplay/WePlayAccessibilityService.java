package com.example.atdweplay;
import android.accessibilityservice.AccessibilityService;import android.view.accessibility.AccessibilityEvent;import android.view.accessibility.AccessibilityNodeInfo;
public class WePlayAccessibilityService extends AccessibilityService {
 public void onAccessibilityEvent(AccessibilityEvent e){AccessibilityNodeInfo root=getRootInActiveWindow(); if(root==null)return; String text=root.getText()!=null?root.getText().toString():""; if(text.contains("WePlay")){ /* Điểm móc để phân tích cây giao diện WePlay. Không tự gửi/điều khiển thao tác. */ } }
 public void onInterrupt(){}
}
