package com.example.atdweplay;
import android.content.*;import android.graphics.Color;import android.graphics.drawable.GradientDrawable;import android.view.*;import android.widget.*;
public class Overlay { static View v; static void show(Context c){ if(v!=null)return; WindowManager wm=(WindowManager)c.getSystemService(Context.WINDOW_SERVICE); LinearLayout box=new LinearLayout(c);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(18,12,18,14); GradientDrawable bg=new GradientDrawable();bg.setColor(0xEEFFFFFF);bg.setCornerRadius(28);box.setBackground(bg);
 TextView head=new TextView(c);head.setText("🕵️  ATD • TỪ KHÓA");head.setTextSize(17);head.setTextColor(Color.DKGRAY);box.addView(head);
 TextView pair=new TextView(c);pair.setText("BÊN MÌNH: —\nBÊN KIA: —\n\nChờ WePlay hiển thị từ khóa...");pair.setTextSize(18);pair.setPadding(4,14,4,8);box.addView(pair);
 EditText search=new EditText(c);search.setHint("Tra từ / tìm từ liên quan");box.addView(search);
 TextView result=new TextView(c);result.setText("Gợi ý sẽ hiện ở đây");result.setTextSize(15);box.addView(result);
 search.setOnEditorActionListener((x,a,e)->{String q=search.getText().toString().trim();result.setText(q.isEmpty()?"Gợi ý sẽ hiện ở đây":"Từ đang tra: "+q+"\nGợi ý: đặc điểm • công dụng • nơi thường gặp");return false;});
 box.setOnTouchListener(new View.OnTouchListener(){float sx,sy;WindowManager.LayoutParams p;public boolean onTouch(View vv,android.view.MotionEvent e){if(e.getAction()==0){sx=e.getRawX();sy=e.getRawY();p=(WindowManager.LayoutParams)box.getLayoutParams();return true;}if(e.getAction()==2){p.x+=(int)(e.getRawX()-sx);p.y+=(int)(e.getRawY()-sy);sx=e.getRawX();sy=e.getRawY();wm.updateViewLayout(box,p);return true;}return true;}});
 WindowManager.LayoutParams p=new WindowManager.LayoutParams(650,WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, -3);p.gravity=Gravity.TOP|Gravity.CENTER_HORIZONTAL;p.y=130;wm.addView(box,p);v=box; }
}
