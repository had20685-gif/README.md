package com.example.atdweplay;

import android.app.*;import android.content.*;import android.graphics.Color;import android.graphics.drawable.GradientDrawable;import android.net.Uri;import android.os.*;import android.provider.Settings;import android.view.*;import android.widget.*;

public class MainActivity extends Activity {
  TextView status;
  public void onCreate(Bundle b){super.onCreate(b); LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(32,40,32,32);
    TextView t=new TextView(this);t.setText("ATD WePlay");t.setTextSize(28);t.setTextColor(Color.DKGRAY);l.addView(t);
    status=new TextView(this);status.setText("Trợ năng: kiểm tra\nQuyền hiển thị: kiểm tra");status.setTextSize(18);l.addView(status);
    Button overlay=new Button(this);overlay.setText("BẬT QUYỀN HIỂN THỊ");overlay.setOnClickListener(v->{startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName())));});l.addView(overlay);
    Button access=new Button(this);access.setText("MỞ CÀI ĐẶT TRỢ NĂNG");access.setOnClickListener(v->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));l.addView(access);
    Button bubble=new Button(this);bubble.setText("HIỆN BẢNG NỔI");bubble.setOnClickListener(v->Overlay.show(this));l.addView(bubble); setContentView(l); }
  protected void onResume(){super.onResume(); if(status!=null)status.setText("Trợ năng: bật trong Cài đặt nếu muốn tự đọc WePlay\nQuyền hiển thị: "+(Settings.canDrawOverlays(this)?"ĐÃ BẬT":"CHƯA BẬT"));}
}
