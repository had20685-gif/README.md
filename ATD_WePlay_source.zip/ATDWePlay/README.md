# ATD WePlay – bản Android mẫu
- Cửa sổ nổi có thể kéo.
- Ô tra từ khóa.
- Khung BÊN MÌNH / BÊN KIA.
- Có khung AccessibilityService để đọc nội dung hiển thị, nhưng việc nhận diện chính xác từ khóa WePlay cần kiểm tra UI thực tế của phiên bản WePlay trên máy.

## Build
Mở thư mục bằng Android Studio và Build > Build APK(s).
Cấp quyền “Hiển thị trên ứng dụng khác” và bật ATD trong Trợ năng.
